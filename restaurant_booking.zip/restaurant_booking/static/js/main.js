// Обработка бронирования
document.querySelectorAll('.book-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const restaurantId = this.dataset.restaurant;
        const tableId = this.dataset.table;
        const time = this.dataset.time;
        
        // Здесь можно добавить AJAX-запрос или перенаправление
        alert(`Бронирование столика №${tableId} на ${time}`);
    });
});

// Поиск ресторанов
const searchForm = document.getElementById('search-form');
if (searchForm) {
    searchForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const query = this.querySelector('input[name="query"]').value;
        window.location.href = `/search/?query=${encodeURIComponent(query)}`;
    });
}