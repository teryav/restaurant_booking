from django.db import models
from django.contrib import admin

class Restaurant(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название")
    address = models.TextField(verbose_name="Адрес")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    description = models.TextField(blank=True, verbose_name="Описание")
    main_photo = models.ImageField(upload_to='restaurants/', verbose_name="Фото", blank=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Дата обновления")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Ресторан"
        verbose_name_plural = "Рестораны"

class Cuisine(models.Model):
    name = models.CharField(max_length=50, verbose_name="Название")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Кухня"
        verbose_name_plural = "Кухни"

class Table(models.Model):
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, verbose_name="Ресторан")
    code = models.CharField(max_length=10, verbose_name="Номер столика")
    capacity = models.PositiveIntegerField(verbose_name="Вместимость")

    def __str__(self):
        return f"Столик {self.code} ({self.restaurant.name})"

    class Meta:
        verbose_name = "Столик"
        verbose_name_plural = "Столики"

class Customer(models.Model):
    name = models.CharField(max_length=100, verbose_name="ФИО")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    email = models.EmailField(verbose_name="Email")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата регистрации")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Клиент"
        verbose_name_plural = "Клиенты"

class Booking(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Ожидает подтверждения'),
        ('confirmed', 'Подтверждено'),
        ('cancelled', 'Отменено'),
        ('completed', 'Завершено'),
    ]

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, verbose_name="Клиент")
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, verbose_name="Ресторан")
    date = models.DateField(verbose_name="Дата")
    time = models.TimeField(verbose_name="Время")
    guests = models.PositiveIntegerField(verbose_name="Количество гостей")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name="Статус")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Дата обновления")
    tables = models.ManyToManyField(Table, through='BookingTable', verbose_name="Столики")

    def __str__(self):
        return f"Бронь #{self.id} - {self.customer.name}"

    @admin.display(description="Информация о брони")
    def booking_info(self):
        return f"{self.date} {self.time}, {self.guests} гостей"

    class Meta:
        verbose_name = "Бронирование"
        verbose_name_plural = "Бронирования"

class BookingTable(models.Model):
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, verbose_name="Бронирование")
    table = models.ForeignKey(Table, on_delete=models.CASCADE, verbose_name="Столик")

    def __str__(self):
        return f"{self.booking} - {self.table}"

    class Meta:
        verbose_name = "Бронь столика"
        verbose_name_plural = "Брони столиков"

class RestaurantCuisine(models.Model):
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, verbose_name="Ресторан")
    cuisine = models.ForeignKey(Cuisine, on_delete=models.CASCADE, verbose_name="Кухня")

    def __str__(self):
        return f"{self.restaurant} - {self.cuisine}"

    class Meta:
        verbose_name = "Кухня ресторана"
        verbose_name_plural = "Кухни ресторанов"
# Create your models here.
