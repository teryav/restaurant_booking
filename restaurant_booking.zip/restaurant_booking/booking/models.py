from django.db import models
from django.contrib import admin
from django.utils import timezone

class Cuisine(models.Model):
    name = models.CharField(max_length=50, verbose_name="Тип кухни")
    
    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Кухня"
        verbose_name_plural = "Кухни"

class Restaurant(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название")
    address = models.TextField(verbose_name="Адрес")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    description = models.TextField(blank=True, verbose_name="Описание")
    main_photo = models.ImageField(upload_to='restaurants/', verbose_name="Фото", blank=True, null=True, default='')
    rating = models.DecimalField(max_digits=3, decimal_places=1, default=0.0)
    cuisines = models.ManyToManyField(Cuisine, related_name='restaurants')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Ресторан"
        verbose_name_plural = "Рестораны"

class Table(models.Model):
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name='tables')
    code = models.CharField(max_length=10, verbose_name="Номер столика")
    capacity = models.PositiveIntegerField(verbose_name="Вместимость")

    def __str__(self):
        return f"Столик {self.code} ({self.restaurant.name})"

    class Meta:
        verbose_name = "Столик"
        verbose_name_plural = "Столики"

class Promotion(models.Model):
    title = models.CharField(max_length=100, verbose_name="Название акции")
    description = models.TextField(verbose_name="Описание")
    start_date = models.DateField(verbose_name="Дата начала")
    end_date = models.DateField(verbose_name="Дата окончания")
    discount = models.PositiveIntegerField(verbose_name="Размер скидки (%)")
    restaurant = models.ForeignKey(
        Restaurant, 
        on_delete=models.CASCADE, 
        related_name='promotions',
        verbose_name="Ресторан"
    )
    image = models.ImageField(
        upload_to='promotions/', 
        verbose_name="Изображение",
        blank=True,
        null=True
    )

    def __str__(self):
        return f"{self.title} ({self.restaurant.name})"

    class Meta:
        verbose_name = "Акция"
        verbose_name_plural = "Акции"
        ordering = ['-start_date']

class Booking(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Ожидает подтверждения'),
        ('confirmed', 'Подтверждено'),
        ('cancelled', 'Отменено'),
        ('completed', 'Завершено'),
    ]

    customer = models.ForeignKey('Customer', on_delete=models.CASCADE, related_name='bookings')
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name='bookings')
    table = models.ForeignKey(Table, on_delete=models.CASCADE, related_name='bookings', null=True, blank=True)
    date = models.DateField(verbose_name="Дата")
    time = models.TimeField(verbose_name="Время")
    guests = models.PositiveIntegerField(verbose_name="Количество гостей")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Бронь #{self.id} - {self.customer.name}"

    class Meta:
        verbose_name = "Бронирование"
        verbose_name_plural = "Бронирования"

class Customer(models.Model):
    name = models.CharField(max_length=100, verbose_name="ФИО")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    email = models.EmailField(verbose_name="Email", unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Клиент"
        verbose_name_plural = "Клиенты"

class BookingTable(models.Model):
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, verbose_name="Бронирование")
    table = models.ForeignKey(Table, on_delete=models.CASCADE, verbose_name="Столик")

    def __str__(self):
        return f"{self.booking} - {self.table}"

    class Meta:
        verbose_name = "Бронь столика"
        verbose_name_plural = "Брони столиков"

class RestaurantCuisine(models.Model):
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, verbose_name="Ресторан")
    cuisine = models.ForeignKey(Cuisine, on_delete=models.CASCADE, verbose_name="Кухня")

    def __str__(self):
        return f"{self.restaurant} - {self.cuisine}"

    class Meta:
        verbose_name = "Кухня ресторана"
        verbose_name_plural = "Кухни ресторанов"
# Create your models here.
