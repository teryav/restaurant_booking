from django.core.management.base import BaseCommand
from booking.models import Restaurant, Cuisine, Table, Booking, Promotion, Customer
from datetime import datetime, timedelta, time
import random

class Command(BaseCommand):
    help = 'Fill database with test data'

    def handle(self, *args, **options):
        # 1. Сначала создаем тестовых клиентов
        customers = [
            {'name': 'Иван Иванов', 'phone': '+79161112233', 'email': 'ivan@example.com'},
            {'name': 'Мария Петрова', 'phone': '+79162223344', 'email': 'maria@example.com'},
            {'name': 'Алексей Сидоров', 'phone': '+79163334455', 'email': 'alex@example.com'}
        ]
        
        for data in customers:
            Customer.objects.get_or_create(**data)

        # 2. Создаем кухни
        cuisines = ['Итальянская', 'Японская', 'Русская', 'Грузинская', 'Французская']
        for name in cuisines:
            Cuisine.objects.get_or_create(name=name)
        
        # 3. Создаем рестораны
        restaurants_data = [
            {'name': 'Pasta Bar', 'address': 'ул. Ленина, 10', 'phone': '+79161234567'},
            {'name': 'Суши Wok', 'address': 'пр. Мира, 25', 'phone': '+79167654321'},
        ]
        
        for data in restaurants_data:
            restaurant = Restaurant.objects.create(**data)
            
            # Добавляем кухни к ресторану
            for _ in range(random.randint(1, 3)):
                cuisine = Cuisine.objects.order_by('?').first()
                restaurant.cuisines.add(cuisine)
            
            # Создаем столики
            for i in range(1, 6):
                Table.objects.create(
                    restaurant=restaurant,
                    code=f"{restaurant.name[:1]}{i}",
                    capacity=random.choice([2, 4, 6, 8])
                )

        # 4. Создаем бронирования
        all_customers = list(Customer.objects.all())
        all_tables = list(Table.objects.all())
        
        for _ in range(50):  # Создаем 50 тестовых бронирований
            Booking.objects.create(
                customer=random.choice(all_customers),
                restaurant=random.choice(Restaurant.objects.all()),
                table=random.choice(all_tables),
                date=datetime.now().date() + timedelta(days=random.randint(0, 30)),
                time=time(random.choice([12, 14, 16, 18, 20]), 0),
                guests=random.randint(1, 6),
                status=random.choice(['pending', 'confirmed', 'completed'])
            )

        # 5. Создаем акции
        promotions = [
            {'title': 'Скидка 20% в будни', 'description': 'С 12:00 до 16:00'},
            {'title': 'Бесплатный десерт', 'description': 'При заказе от 2000 руб.'},
        ]
        
        for promo in promotions:
            Promotion.objects.create(
                **promo,
                start_date=datetime.now().date(),
                end_date=datetime.now().date() + timedelta(days=30),
                discount=random.randint(10, 30),
                restaurant=Restaurant.objects.order_by('?').first()
            )

        self.stdout.write(self.style.SUCCESS('База данных успешно заполнена тестовыми данными'))