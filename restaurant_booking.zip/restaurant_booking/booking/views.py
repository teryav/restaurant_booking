from django.shortcuts import render
from django.db.models import Count
from datetime import datetime, time
from .models import Restaurant, Booking, Promotion

def home(request):
    # Популярные рестораны
    popular_restaurants = Restaurant.objects.annotate(
        bookings_count=Count('bookings')
    ).order_by('-bookings_count')[:5]
    
    # Доступные слоты на сегодня
    today = datetime.now().date()
    available_slots = Booking.objects.filter(
        date=today,
        status='available',
        time__gte=datetime.now().time()
    ).select_related('restaurant', 'table')[:10]
    
    # Акции
    promotions = Promotion.objects.filter(
        start_date__lte=today,
        end_date__gte=today
    ).select_related('restaurant')[:3]
    
    context = {
        'popular_restaurants': popular_restaurants,
        'available_slots': available_slots,
        'promotions': promotions,
    }
    return render(request, 'booking/index.html', context)

def all_restaurants(request):
    """Отображение списка всех ресторанов"""
    restaurants = Restaurant.objects.all().order_by('name')
    return render(request, 'booking/all_restaurants.html', {
        'restaurants': restaurants
    })

def restaurant_detail(request, pk):
    """Детальная страница ресторана"""
    restaurant = Restaurant.objects.get(pk=pk)
    return render(request, 'booking/restaurant_detail.html', {
        'restaurant': restaurant
    })

def search(request):
    """Поиск ресторанов"""
    query = request.GET.get('query', '')
    results = Restaurant.objects.filter(name__icontains=query)
    return render(request, 'booking/search.html', {
        'results': results,
        'query': query
    })
# Create your views here.
