from django.contrib import admin
from .models import *

class BookingTableInline(admin.TabularInline):
    model = BookingTable
    extra = 1
    verbose_name = "Столик"
    verbose_name_plural = "Столики для брони"

class RestaurantCuisineInline(admin.TabularInline):
    model = RestaurantCuisine
    extra = 1
    verbose_name = "Кухня"
    verbose_name_plural = "Кухни ресторана"

@admin.register(Restaurant)
class RestaurantAdmin(admin.ModelAdmin):
    list_display = ('name', 'address', 'phone', 'cuisines_list')
    list_filter = ('created_at', 'updated_at')
    inlines = [RestaurantCuisineInline]
    search_fields = ('name', 'address', 'phone')
    filter_horizontal = ()
    list_display_links = ('name',)
    readonly_fields = ('created_at', 'updated_at')
    date_hierarchy = 'created_at'

    @admin.display(description="Кухни")
    def cuisines_list(self, obj):
        return ", ".join([c.name for c in obj.cuisine_set.all()])

@admin.register(Cuisine)
class CuisineAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

@admin.register(Table)
class TableAdmin(admin.ModelAdmin):
    list_display = ('code', 'restaurant', 'capacity')
    list_filter = ('restaurant',)
    search_fields = ('code', 'restaurant__name')

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'email', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('name', 'phone', 'email')
    date_hierarchy = 'created_at'

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('id', 'customer', 'restaurant', 'get_booking_info', 'status', 'created_at')
    list_filter = ('status', 'date', 'restaurant')
    inlines = [BookingTableInline]
    search_fields = ('customer__name', 'restaurant__name')
    filter_horizontal = ()
    list_display_links = ('id', 'customer')
    readonly_fields = ('created_at', 'updated_at')
    date_hierarchy = 'created_at'
    raw_id_fields = ('customer', 'restaurant')

    @admin.display(description='Информация о брони')
    def get_booking_info(self, obj):
        return f"{obj.date} {obj.time}, {obj.guests} гостей"
    

@admin.register(BookingTable)
class BookingTableAdmin(admin.ModelAdmin):
    list_display = ('booking', 'table')
    list_filter = ('booking__status',)
    raw_id_fields = ('booking', 'table')

@admin.register(RestaurantCuisine)
class RestaurantCuisineAdmin(admin.ModelAdmin):
    list_display = ('restaurant', 'cuisine')
    list_filter = ('cuisine',)
    raw_id_fields = ('restaurant', 'cuisine')

# Register your models here.
